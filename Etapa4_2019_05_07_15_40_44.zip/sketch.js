/* 
    Equipe: 
        Jéssica Aparecida Silva Costa - Subturma D (Líder) 
        Patrick William de Carvalho Segundo- Subturma A
        Etapa 4
*/
var xo= 250;
var yo= 225;
var pulo= false;
var yp= 0;
var xdo, ydo;
var contFrames= 0;
function setup() {
  createCanvas(400, 400);
  xdo=30;
  ydo=250;
  frameRate ( 30 );
}

function draw() {


 if ( keyIsDown ( UP_ARROW ) && ( ! pulo)) {
		pulo =  true ;
		contFrames =  0 ;
	}
  if (pulo) {
		contFrames ++ ; 
     yp =  (0,01 * (contFrames) * (contFrames - 30));
    if ( yp >  0 ) {
      pulo =  false ;
            
			yp =  0 ; 		
		}
	}
  background(150);
  ellipse(xdo , ydo + yp, 20, 50);
  xdo=xdo+2;
  if(xdo>300){xdo=40}
  rect ( xo , yo , 20 , 50 );
   xo = xo -  2 ;
 if(xo<40)
 {
   xo=random(1000);
   console.log(xo);
 }
}